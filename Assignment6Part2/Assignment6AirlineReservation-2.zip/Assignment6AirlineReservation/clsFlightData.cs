﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Class that contains all information regarding the flight.
    /// </summary>
    public class clsFlightData
    {
        /// <summary>
        /// Declaration of the flightID variable.
        /// </summary>
        private int flightID;

        /// <summary>
        /// Declaration of the flightNumber variable.
        /// </summary>
        private string flightNumber;

        /// <summary>
        /// Declaration of the aircraftType variable.
        /// </summary>
        private string aircraftType;

        /// <summary>
        /// Get/Set the flightID property.
        /// </summary>
        public int FlightID
        {
            get { return flightID; }
            set { flightID = value; }
        }

        /// <summary>
        /// Get/Set the flightNumber property.
        /// </summary>
        public string FlightNumber
        {
            get { return flightNumber; }
            set { flightNumber = value; }
        }

        /// <summary>
        /// Get/Set the aircraftType property.
        /// </summary>
        public string AircraftType
        {
            get { return aircraftType; }
            set { aircraftType = value; }
        }

        /// <summary>
        /// Overridden ToString method to return the flightNumber and aircraftType
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return FlightNumber + " - " + aircraftType;
        }
    }
}
