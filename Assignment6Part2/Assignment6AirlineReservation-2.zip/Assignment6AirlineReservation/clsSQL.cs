﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// This class contains all of the SQL queries used to manipulate data in the DB.
    /// </summary>
    public class clsSQL
    {
        /// <summary>
        /// This method will return a query string that queries all flight information.
        /// </summary>
        /// <returns>String of flight data.</returns>
        public string getFlights()
        {
            string sSQL = "SELECT Flight_ID, Flight_Number, Aircraft_Type FROM FLIGHT";
            return sSQL;
        }

        /// <summary>
        /// This method will return a string query for all passenger data and their seat number.
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns>String of passenger data.</returns>
        public string getPassengers(int flightID)
        {
            string sSQL = "SELECT Passenger.Passenger_ID, First_Name, Last_Name, FPL.Seat_Number " +
                              "FROM Passenger, Flight_Passenger_Link FPL " +
                              "WHERE Passenger.Passenger_ID = FPL.Passenger_ID AND " +
                              "Flight_ID = " + flightID;
            return sSQL;
        }

        /// <summary>
        /// This query collects all passenger seat numbers based on the flightID
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns>String of seat numbers.</returns>
        public string getTakenSeats(int flightID)
        {
            return "SELECT Seat_Number FROM Flight_Passenger_Link WHERE Flight_ID = " + flightID;
        }
    }
}
