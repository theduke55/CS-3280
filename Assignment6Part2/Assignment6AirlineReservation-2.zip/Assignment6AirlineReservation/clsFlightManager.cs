﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// This class is used to query the DB and get the flight data and return it to the UI
    /// </summary>
    public class clsFlightManager
    {
        /// <summary>
        /// Instantiate a clsSQL object.
        /// </summary>
        clsSQL sql = new clsSQL();

        /// <summary>
        /// This method interacts with the SQL class and the DB to fill a list of flight objects.
        /// </summary>
        /// <returns>List of flight objects.</returns>
        public List<clsFlightData> GetFlights()
        {
            //Instantiate a list object.
            List<clsFlightData> lstFlights = new List<clsFlightData>();

            //Declare the counter for the DB
            int iRet = 0;

            //Instantiate the clsDataAccess object
            clsDataAccess clsData = new clsDataAccess();

            //Initialize a query variable using the clsSQL class and getFlights method.
            var query = sql.getFlights();

            //Fill the DataSet object with the results from the query.
            var dataSet = clsData.ExecuteSQLStatement(query, ref iRet);

            //Create a new flight object for each row in the DB and copy the values to the list.
            for (int i = 0; i < iRet; i++)
            {
                clsFlightData flight = new clsFlightData();
                flight.FlightID = (int)dataSet.Tables[0].Rows[i][0];
                flight.FlightNumber = (string)dataSet.Tables[0].Rows[i][1];
                flight.AircraftType = (string)dataSet.Tables[0].Rows[i][2];
                lstFlights.Add(flight);
            }

            //Return the list containing flight objects.
            return lstFlights;
        }

        /// <summary>
        /// This method creates a list of passengers using the flightID from the combobox.
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns></returns>
        public List<clsPassengerData> GetPassengers(int flightID)
        {
            //Instantiate a clsPassengerData object.
            List<clsPassengerData> lstPassengers = new List<clsPassengerData>();

            //Initialize the counter for the DB.
            int iRet = 0;

            //Instantiate a clsDataAccess object.
            clsDataAccess clsData = new clsDataAccess();

            //Initialize the query variable using the clsSQL class and its getPassengers method.
            var query = sql.getPassengers(flightID);

            //Fill the DataSet object with the results from the above query.
            var dataSet = clsData.ExecuteSQLStatement(query, ref iRet);

            //Copy the contents from the DataSet object to a list
            for (int i = 0; i < iRet; i++)
            {
                clsPassengerData passenger = new clsPassengerData();
                passenger.PassengerID = (int)dataSet.Tables[0].Rows[i][0];
                passenger.FirstName = (string)dataSet.Tables[0].Rows[i][1];
                passenger.LastName = (string)dataSet.Tables[0].Rows[i][2];
                passenger.seat_Number = (string)dataSet.Tables[0].Rows[i][3];
                lstPassengers.Add(passenger);
            }

            //Return the list of passengers.
            return lstPassengers;
        }
    }
}
