﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Declare a clsDataAccess object.
        /// </summary>
        clsDataAccess clsData;

        /// <summary>
        /// Declare a wndAddPassenger object.
        /// </summary>
        wndAddPassenger wndAddPass;

        /// <summary>
        /// Declare a clsFlightManager object.
        /// </summary>
        clsFlightManager FlightManager;

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;

                //Instantiate the FlightManager object.
                FlightManager = new clsFlightManager();

                //Bind the cbChooseFlight combobox to the list of flight objects in FlightManager
                cbChooseFlight.ItemsSource = FlightManager.GetFlights();
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Method for handling the event when the cbChooseFlight is selected.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbChooseFlight_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //Store the flight object into a variable called selection
                var selection = (clsFlightData)cbChooseFlight.SelectedItem;

                //Enable the user to click on the cbChoosePassenger combobox and the passenger commands.
                cbChoosePassenger.IsEnabled = true;
                gPassengerCommands.IsEnabled = true;
                
                //Store the list of passenger objects into a list.
                var passengerList = FlightManager.GetPassengers(selection.FlightID);

                //Bind the passengerList to the cbChoosePassenger combobox.
                cbChoosePassenger.ItemsSource = passengerList;

                //If the flight object selected is the 767 show it and hide the A380
                if (selection.FlightID == 1)
                {
                    CanvasA380.Visibility = Visibility.Hidden;
                    Canvas767.Visibility = Visibility.Visible;
                }
                //Else do the opposite.
                else
                {
                    Canvas767.Visibility = Visibility.Hidden;
                    CanvasA380.Visibility = Visibility.Visible;
                }

                //Clear the list of passenger objects contained in the combobox
                cbChoosePassenger.Items.Clear();
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// This method handles the event when a user clicks the AddPassenger button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdAddPassenger_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Instantiate the wndAddPassenger object.
                wndAddPass = new wndAddPassenger();

                //Display the window for adding a passenger.
                wndAddPass.ShowDialog();
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                    MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Method for handling all errors and appending them to a file.
        /// </summary>
        /// <param name="sClass"></param>
        /// <param name="sMethod"></param>
        /// <param name="sMessage"></param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (System.Exception ex)
            {
                System.IO.File.AppendAllText(@"C:\Error.txt", Environment.NewLine + "HandleError Exception: " + ex.Message);
            }
        }
    }
}
