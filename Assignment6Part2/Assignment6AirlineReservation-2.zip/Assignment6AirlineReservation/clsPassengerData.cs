﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Class containing properties relating to passenger objects.
    /// </summary>
    public class clsPassengerData
    {
        /// <summary>
        /// The passenger ID used in the DB.
        /// </summary>
        private int passengerID;
        
        /// <summary>
        /// The first name of the passenger.
        /// </summary>
        private string firstName;

        /// <summary>
        /// The last name of the passenger.
        /// </summary>
        private string lastName;

        /// <summary>
        /// Get/Set the passengerID.
        /// </summary>
        public int PassengerID
        {
            get { return passengerID; }
            set { passengerID = value; }
        }

        /// <summary>
        /// Get/Set the passengers first name.
        /// </summary>
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        /// <summary>
        /// Get/Set the passengers last name.
        /// </summary>
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        
        /// <summary>
        /// Get/Set the passengers seat number.
        /// </summary>
        public string seat_Number
        {
            get;
            set;
        }

        /// <summary>
        /// Overridden method to display the first and last name of the passenger.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return firstName + " " + lastName;
        }
    }
}
