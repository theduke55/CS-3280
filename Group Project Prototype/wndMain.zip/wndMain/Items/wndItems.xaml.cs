﻿using System;
using System.Data;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace GroupProject
{
    /// <summary>
    /// Associated cs class for wndItems.xaml
    /// </summary>
    public partial class wndItems : Window
    {
        /// <summary>
        /// Instance of the logic class, to perform business logic
        /// </summary>
        private clsItemsLogic ItemsLogic;

        /// <summary>
        /// The Id of the selected row when the user clicks inside the DataSet
        /// </summary>
        private string SelectedItemId;

        /// <summary>
        /// Shows if a data row inside the DataSet is selected
        /// </summary>
        private bool IsDataRowSelected = false;

        /// <summary>
        /// Constructor for this class. This sets everything up when the Items window is launched.
        /// </summary>
        public wndItems()
        {
            InitializeComponent();
            ItemsLogic = new clsItemsLogic();
            GetItemDataset();
        }

        /// <summary>
        /// Calls the Logic class to get the Items DataSet. 
        /// After it receives this, it populates the DataGrid.
        /// </summary>
        private void GetItemDataset()
        {
            try
            {
                var dataset = ItemsLogic.GetItems();
                ItemsDataGrid.ItemsSource = dataset.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// When the Add button is clicked, this method validates the data in the 
        /// textboxes, then calls the Logic class to add the new Item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBoxesAreFilled())
                {
                    ItemsLogic.AddItems(DescriptionTextBox.Text, PriceTextBox.Text);
                    GetItemDataset();
                    DescriptionTextBox.Text = "";
                    PriceTextBox.Text = "";
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// When the Update button is clicked, this method validates the data in the textboxes 
        /// and checks that a row is selected, then calls the Logic class to update the selected Item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (DataRowIsSelected() && TextBoxesAreFilled())
                {
                    ItemsLogic.UpdateItems(SelectedItemId, DescriptionTextBox.Text, PriceTextBox.Text);
                    GetItemDataset();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// When the Delete button is clicked, this method checks that a row is selected and
        /// checks that the item can be deleted. It then calls the Logic class 
        /// to update the selected Item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (DataRowIsSelected() && ClearedToDeleteItem(SelectedItemId))
                {
                    ItemsLogic.DeleteItems(SelectedItemId);
                    GetItemDataset();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Helper method that checks if the Description and Price textboxes are filled, and
        /// that the Price contains a decimal.
        /// </summary>
        /// <returns>A true/false value on if the textboxes are filled</returns>
        private bool TextBoxesAreFilled()
        {
            try
            {
                var isDiscValid = false;
                var isPriceValid = false;

                if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
                    DescriptionErrorLabel.Visibility = Visibility.Visible;
                else
                {
                    DescriptionErrorLabel.Visibility = Visibility.Hidden;
                    isDiscValid = true;
                }

                if (!decimal.TryParse(PriceTextBox.Text, out decimal price))
                    PriceErrorLabel.Visibility = Visibility.Visible;
                else
                {
                    PriceErrorLabel.Visibility = Visibility.Hidden;
                    isPriceValid = true;
                }

                return (isDiscValid && isPriceValid);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This event is called every time a new row is selected in the DataGrid. This method verifies
        /// if a row is selected, and passes the Id, description, and price for the new row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                IsDataRowSelected = true;
                
                var selectedItem = (DataRowView)ItemsDataGrid.SelectedItem;

                if (selectedItem == null) // Happens after Update or Delete
                {
                    IsDataRowSelected = false;
                    DescriptionTextBox.Text = "";
                    PriceTextBox.Text = "";
                    return;
                }

                var id = (int)selectedItem.Row.ItemArray[0];
                var description = (string)selectedItem.Row.ItemArray[1];
                var price = (decimal)selectedItem.Row.ItemArray[2];

                SelectedItemId = id.ToString();
                DescriptionTextBox.Text = description;
                PriceTextBox.Text = price.ToString();
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Verifies that a row is selected, using the global variable.
        /// </summary>
        /// <returns>If a row in the DataGrid is selected</returns>
        private bool DataRowIsSelected()
        {
            try
            {
                if (IsDataRowSelected == false)
                    RowSelectionErrorLabel.Visibility = Visibility.Visible;
                else
                    RowSelectionErrorLabel.Visibility = Visibility.Hidden;
                return IsDataRowSelected;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Calls the Logic class to check if an Item can be deleted from the database. It
        /// also notifies the user if the Item can't be deleted.
        /// </summary>
        /// <param name="itemId"></param>
        /// <returns>If an Item can be deleted</returns>
        private bool ClearedToDeleteItem(string itemId)
        {
            try
            {
                var cantDelete = ItemsLogic.ItemIsInInvoice(itemId);

                if (cantDelete)
                    DeleteItemErrorTextBlock.Visibility = Visibility.Visible;
                else
                    DeleteItemErrorTextBlock.Visibility = Visibility.Hidden;
                return !cantDelete;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
