﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    class clsMainLogic
    {
        /// <summary>
        /// Instantiate a clsMainSQL object.
        /// </summary>
        public clsMainSQL clsMainSQL = new clsMainSQL();
        
        /// <summary>
        /// This method executes a SQL query on the database to return all items.
        /// </summary>
        /// <returns></returns>
        public DataSet getItems()
        {
            try
            {
                var iRetVal = 0;
                var query = clsMainSQL.getItems();
                return clsMainSQL.ExecuteSQLStatement(query, ref iRetVal);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This method executes a SQL query to return a price based on the items description.
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        public string getPrice(string description)
        {
            try
            {
                var query = clsMainSQL.getPrice(description);
                return clsMainSQL.ExecuteScalarSQL(query);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This method executes a SQL query to return a single row based on the items description.
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        public string getItemRecord(string description)
        {
            try
            {
                var query = clsMainSQL.getItemRecord(description);
                return clsMainSQL.ExecuteScalarSQL(query);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
