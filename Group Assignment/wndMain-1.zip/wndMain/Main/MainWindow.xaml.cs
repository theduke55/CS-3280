﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GroupProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Instantiate a clsMainSQL object.
        /// </summary>
        clsMainSQL clsMainSQL = new clsMainSQL();

        /// <summary>
        /// Instantiate a clsMainLogic object.
        /// </summary>
        clsMainLogic clsMainLogic = new clsMainLogic();

        /// <summary>
        /// Declare a DataSet object.
        /// </summary>
        public DataSet myInvoice;

        /// <summary>
        /// This is a temporary DataTable to test placing items into the datagrid
        /// </summary>
        public DataTable dataTable = new DataTable("items");

        public MainWindow()
        {
            InitializeComponent();

            //Updates the datagrid with items in the database. 
            //UpdateDataGrid();

            //Fill the combobox with items from the database.
            UpdateComboBox();

            //Instantiate the DataSet object.
            myInvoice = new DataSet();


        }

        /// <summary>
        /// This method will handle displaying the Search Window and hiding the Main Menu Window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Hide the main menu
                this.Hide();

                //Instantiating Search Window object
                wndSearch wndSearch = new wndSearch();

                //Display the Search Window
                wndSearch.ShowDialog();

                //Display the Main Menu Window
                this.Show();

                //Pass the Primary Key value of the selected invoice to the Main Menu
                string invoiceNumber = "";
                invoiceNumber = wndSearch.invoiceID;

                //Display the invoice if one was selected from the Search window
                if (invoiceNumber != "")
                {
                    //call a SQL query to return the invoice based on the invoiceID
                }

                //Delete the Search Window object
                wndSearch.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }

        /// <summary>
        /// This method handles hiding the Main Menu and showing the Items Window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                //Hide the Main Menu
                this.Hide();

                //Instantiate a wndItems object.
                wndItems wndItems = new wndItems();

                //Display the Items Window
                wndItems.ShowDialog();

                //Display the Main Menu
                this.Show();
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Method for handling events when the 'Add Item' button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Disable the buttons to display the other windows.
                SearchForInvoice.IsEnabled = false;
                SearchForItems.IsEnabled = false;

                //The following code is a test to insert data into the datagrid.
                //It will not be used for the final.
                dataTable.Columns.Add(new DataColumn("Description", typeof(string)));
                myInvoice.Tables.Add(dataTable);
                DataRow newRow = myInvoice.Tables[0].NewRow();
                newRow["Description"] = "some garbage";
                myInvoice.Tables[0].Rows.Add(newRow);
                dataGrid.ItemsSource = myInvoice.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This method handles events when the combobox selects an item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //Enable the 'Add Item' button
                button2.IsEnabled = true;

                /*The combobox didn't work as intended therefore this code is irrelevant right now.
                if(comboBox.SelectedIndex == -1)
                {
                    button2.IsEnabled = false;
                    return;
                }*/

                //Store the selected item into a selectedItem variable.
                string selectedItem = comboBox.SelectedItem.ToString();

                //Pass the selectedItem into a SQL query to return the price.
                getPrice(selectedItem);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Method for getting all of the items from the Items table and then
        /// displays them in the datagrid.
        /// </summary>
        private void UpdateDataGrid()
        {
            try
            {
                var DataSet = clsMainLogic.getItems();
                dataGrid.ItemsSource = DataSet.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Method for getting all of the items from the Item table and 
        /// populating them in the combobox.
        /// </summary>
        private void UpdateComboBox()
        {
            try
            {
                //Call the method in clsMainLogic to return all items from the Items table.
                DataSet list = clsMainLogic.getItems();

                //Loop through the list and add them to the combobox
                for (int i = 0; i < list.Tables[0].Rows.Count; i++)
                {
                    comboBox.Items.Add(list.Tables[0].Rows[i][1]);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Method for both calling a clsMainLogic method to return the items price
        /// then displaying it to the price textbox.
        /// </summary>
        /// <param name="description"></param>
        private void getPrice(string description)
        {
            try
            {
                textBox1.Text = clsMainLogic.getPrice(description);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
