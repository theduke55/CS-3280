﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GroupProject
{
    /// <summary>
    /// Interaction logic for wndSearch.xaml
    /// </summary>
    public partial class wndSearch : Window
    {
        /// <summary>
        /// Initialize an instance of the Logic class
        /// </summary>
        clsSearchLogic logic = new clsSearchLogic();

        /// <summary>
        /// This is a dataset that will hold all of the invoices returned by the database
        /// </summary>
        DataSet invoiceTable;

        /// <summary>
        /// This is the id of the currently selected invoice. This will be grabbed by the main window
        /// </summary>
        public string invoiceID;

        public wndSearch()
        {
            InitializeComponent();
            Update_Invoice_Grid(null, null, null);
            Update_ComboBoxes();
        }

        /// <summary>
        /// This method will fill all of the filter dropdown lists from the returned dataset
        /// </summary>
        private void Update_ComboBoxes()
        {
            try
            {
                DataSet list = logic.Populate_ComboBox();

                for (int i = 0; i < list.Tables[0].Rows.Count; i++)
                {
                    InvoiceNumDropdown.Items.Add(list.Tables[0].Rows[i][0].ToString());
                    InvoiceDateDropdown.Items.Add(list.Tables[0].Rows[i][1].ToString());
                    if (!TotalChargeDropdown.Items.Contains(list.Tables[0].Rows[i][2].ToString()))
                    {
                        TotalChargeDropdown.Items.Add(list.Tables[0].Rows[i][2].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// This function will clear all of the filters (dropdowns) and then repopulate the datagrid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Reset_Filters(object sender, RoutedEventArgs e)
        {
            try
            {
                InvoiceDateDropdown.SelectedIndex = -1;
                InvoiceNumDropdown.SelectedIndex = -1;
                TotalChargeDropdown.SelectedIndex = -1;

                Update_Invoice_Grid(null, null, null);
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }
        
        /// <summary>
        /// This method will take the Invoice id, invoice date, and total charge passed into it
        /// and pass that to the logic class to get a DataSet object of the invoices in the database
        /// based off the users filters (if any are selected)
        /// </summary>
        /// <param name="id"></param>
        /// <param name="date"></param>
        /// <param name="charge"></param>
        private void Update_Invoice_Grid(string id, string date, string charge)
        {
            try
            {
                invoiceTable = logic.Populate_InvoiceGrid(id, date, charge);
                InvoiceGrid.ItemsSource = invoiceTable.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }        

        /// <summary>
        /// This function will take the selected invoice and pass it back to the main window to be opened
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Open_Invoice(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        /// <summary>
        /// This will take the selected invoice num, invoice data, and total charge and filter the invoice datagrid off that.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Dropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string num = null;
                string date = null;
                string charge = null;

                if (InvoiceNumDropdown.SelectedIndex != -1)
                {
                    num = InvoiceNumDropdown.SelectedItem.ToString();
                }
                if (InvoiceDateDropdown.SelectedIndex != -1)
                {
                    date = InvoiceDateDropdown.SelectedItem.ToString();
                }
                if (TotalChargeDropdown.SelectedIndex != -1)
                {
                    charge = TotalChargeDropdown.SelectedItem.ToString();
                }
                Update_Invoice_Grid(num, date, charge);
            }
             catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// This method will hide this window and take the user back to the main window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Cancel_Button(object sender, RoutedEventArgs e)
        {
            invoiceID = null;
            this.Hide();
        }

        /// <summary>
        /// This method will get the invoice id of the currently selected item in the datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InvoiceGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                DataGrid dataGrid = InvoiceGrid;
                DataGridRow Row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(dataGrid.SelectedIndex);
                DataGridCell RowAndColumn = (DataGridCell)dataGrid.Columns[0].GetCellContent(Row).Parent;
                invoiceID = ((TextBlock)RowAndColumn.Content).Text;
            }
            catch (Exception ex)
            {
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Handle the error
        /// </summary>
        /// <param name="sClass"></param>
        /// <param name="sMethod"></param>
        /// <param name="sMessage"></param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }
    }
}
