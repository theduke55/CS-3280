﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    class clsSearchLogic
    {
        /// <summary>
        /// Initialize an instance of the Sql class
        /// </summary>
        clsSearchSQL db = new clsSearchSQL();

        /// <summary>
        /// This invoice will accept the 3 different filters the users specifies (if any), and then create queries based off of those
        /// inputs and pass the query along to the SQL class. It will then return a dataset of the requested data.
        /// </summary>
        /// <param name="invoiceNum"></param>
        /// <param name="invoiceDate"></param>
        /// <param name="totalCharge"></param>
        /// <returns></returns>
        public DataSet Populate_InvoiceGrid(string invoiceNum, string invoiceDate, string totalCharge)
        {
            try
            {
                DataSet invoices = new DataSet();
                string query = "SELECT * FROM Invoices";

                if (invoiceNum != null)
                {
                    query += $" Where ID = {invoiceNum}";
                }
                if (invoiceDate != null)
                {
                    if (!query.Contains("Where"))
                    {
                        query += $" Where InvoiceDate = #{invoiceDate}#";
                    }
                    else
                    {
                        query += $" And InvoiceDate = #{invoiceDate}#";
                    }
                }
                if (totalCharge != null)
                {
                    if (!query.Contains("Where"))
                    {
                        query += $" Where TotalPrice = {totalCharge}";
                    }
                    else
                    {
                        query += $" And TotalPrice = {totalCharge}";
                    }
                }
                int iRet = 0;

                invoices = db.ExecuteSQLStatement(query, ref iRet);
                return invoices;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
            
        }

        /// <summary>
        /// This method passes a query to the sql class and returns a dataset of all the invoices in the database
        /// </summary>
        /// <returns></returns>
        public DataSet Populate_ComboBox()
        {
            try
            {
                DataSet combo = new DataSet();
                //Number of return values
                int iRet = 0;

                //Get all the values from the Authors table
                combo = db.ExecuteSQLStatement("SELECT * FROM Invoices", ref iRet);
                return combo;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }
    }
}
