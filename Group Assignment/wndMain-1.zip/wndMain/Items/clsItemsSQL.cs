﻿using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Reflection;

namespace GroupProject
{
    /// <summary>
    /// The SQL class for the Items entity. The first part of this class was copied from the 
    /// "Chapter 21 DB Class Example" provided by Shawn Cowder. The second part are the SQL 
    /// queries to query the Items table in the database.
    /// </summary>
    public class clsItemsSQL
    {
        /// <summary>
        /// Connection string to the database.
        /// </summary>
        private string sConnectionString;

        /// <summary>
        /// Constructor that sets the connection string to the database
        /// </summary>
		public clsItemsSQL()
        {
            sConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data source= " + Directory.GetCurrentDirectory() + "\\FurnitureInc.mdb";
        }

        /// <summary>
        /// This method takes an SQL statment that is passed in and executes it.  The resulting values
        /// are returned in a DataSet.  The number of rows returned from the query will be put into
        /// the reference parameter iRetVal.
        /// </summary>
        /// <param name="sSQL">The SQL statement to be executed.</param>
        /// <param name="iRetVal">Reference parameter that returns the number of selected rows.</param>
        /// <returns>Returns a DataSet that contains the data from the SQL statement.</returns>
		public DataSet ExecuteSQLStatement(string sSQL, ref int iRetVal)
        {
            try
            {
                //Create a new DataSet
                DataSet ds = new DataSet();

                using (OleDbConnection conn = new OleDbConnection(sConnectionString))
                {
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter())
                    {

                        //Open the connection to the database
                        conn.Open();

                        //Add the information for the SelectCommand using the SQL statement and the connection object
                        adapter.SelectCommand = new OleDbCommand(sSQL, conn);
                        adapter.SelectCommand.CommandTimeout = 0;

                        //Fill up the DataSet with data
                        adapter.Fill(ds);
                    }
                }

                //Set the number of values returned
                iRetVal = ds.Tables[0].Rows.Count;

                //return the DataSet
                return ds;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This method takes an SQL statment that is passed in and executes it.  The resulting single 
        /// value is returned.
        /// </summary>
        /// <param name="sSQL">The SQL statement to be executed.</param>
        /// <returns>Returns a string from the scalar SQL statement.</returns>
		public string ExecuteScalarSQL(string sSQL)
        {
            try
            {
                //Holds the return value
                object obj;

                using (OleDbConnection conn = new OleDbConnection(sConnectionString))
                {
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter())
                    {

                        //Open the connection to the database
                        conn.Open();

                        //Add the information for the SelectCommand using the SQL statement and the connection object
                        adapter.SelectCommand = new OleDbCommand(sSQL, conn);
                        adapter.SelectCommand.CommandTimeout = 0;

                        //Execute the scalar SQL statement
                        obj = adapter.SelectCommand.ExecuteScalar();
                    }
                }

                //See if the object is null
                if (obj == null)
                {
                    //Return a blank
                    return "";
                }
                else
                {
                    //Return the value
                    return obj.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// This method takes an SQL statment that is a non query and executes it.
        /// </summary>
        /// <param name="sSQL">The SQL statement to be executed.</param>
        /// <returns>Returns the number of rows affected by the SQL statement.</returns>
        public int ExecuteNonQuery(string sSQL)
        {
            try
            {
                //Number of rows affected
                int iNumRows;

                using (OleDbConnection conn = new OleDbConnection(sConnectionString))
                {
                    //Open the connection to the database
                    conn.Open();

                    //Add the information for the SelectCommand using the SQL statement and the connection object
                    OleDbCommand cmd = new OleDbCommand(sSQL, conn);
                    cmd.CommandTimeout = 0;

                    //Execute the non query SQL statement
                    iNumRows = cmd.ExecuteNonQuery();
                }

                //return the number of rows affected
                return iNumRows;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        #region Items Queries

        /// <summary>
        /// Query to get all Items from the database.
        /// </summary>
        /// <returns></returns>
        public string GetItems()
        {
            return "SELECT * FROM Items";
        }

        /// <summary>
        /// Query to add an Item to the database.
        /// </summary>
        /// <param name="description">The Item description</param>
        /// <param name="price">The Item price</param>
        /// <returns></returns>
        public string AddItems(string description, string price)
        {
            return $"INSERT INTO ITEMS (Description, Price) VALUES ('{description}', {price})";
        }

        /// <summary>
        /// Query to update an Item from the database.
        /// </summary>
        /// <param name="id">The Id of the Item to update</param>
        /// <param name="description">The description of the Item to update</param>
        /// <param name="price">The price of the Item to update</param>
        /// <returns></returns>
        public string UpdateItems(string id, string description, string price)
        {
            return $"UPDATE Items SET Description = '{description}', Price = {price} WHERE ID = {id}";
        }

        /// <summary>
        /// Query to delete an Item from the database.
        /// </summary>
        /// <param name="id">The Id of the Item to delete</param>
        /// <returns></returns>
        public string DeleteItems(string id)
        {
            return $"DELETE FROM Items WHERE ID = {id}";
        }

        /// <summary>
        /// Query to count the number of instances where an Item exists in the 
        /// InvoiceItems table in the database.
        /// </summary>
        /// <param name="id">The Id of the Item to check.</param>
        /// <returns></returns>
        public string ItemsInInvoiceCount(string id)
        {
            return $"SELECT COUNT(ItemId) FROM InvoiceItems WHERE ItemId = {id}";
        }

        #endregion
    }
}
