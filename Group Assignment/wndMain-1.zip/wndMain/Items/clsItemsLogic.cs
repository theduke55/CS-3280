﻿using System;
using System.Data;
using System.Reflection;

namespace GroupProject
{
    /// <summary>
    /// This is the Business Logic class for Items.
    /// </summary>
    public class clsItemsLogic
    {
        /// <summary>
        /// Instanciates the SQL class, so it can query the database. This provides decoupling between
        /// the database and the business logic.
        /// </summary>
        public clsItemsSQL ItemsSQL = new clsItemsSQL();

        /// <summary>
        /// Calls the SQL class to get a list of Items from the database.
        /// </summary>
        /// <returns>List of Items from the database, provided in a DataSet</returns>
        public DataSet GetItems()
        {
            try
            {
                var iRetVal = 0;
                var query = ItemsSQL.GetItems();
                var dataset = ItemsSQL.ExecuteSQLStatement(query, ref iRetVal);
                return dataset;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Calls the SQL class to add a new item to the database.
        /// </summary>
        /// <param name="description">The Item's description</param>
        /// <param name="price">The Item's price</param>
        public void AddItems(string description, string price)
        {
            try
            {
                var query = ItemsSQL.AddItems(description, price);
                ItemsSQL.ExecuteScalarSQL(query);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Calls the SQL class to update an Item in the database.
        /// </summary>
        /// <param name="id">The Item's Id</param>
        /// <param name="description">The Item's description</param>
        /// <param name="price">The Item's price</param>
        public void UpdateItems(string id, string description, string price)
        {
            try
            {
                var query = ItemsSQL.UpdateItems(id, description, price);
                ItemsSQL.ExecuteScalarSQL(query);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Calls the SQL class to delete an Item in the database.
        /// </summary>
        /// <param name="id">The Item's Id</param>
        public void DeleteItems(string id)
        {
            try
            {
                var query = ItemsSQL.DeleteItems(id);
                ItemsSQL.ExecuteScalarSQL(query);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Calls the SQL class to query if an Item exists in any invoice in the database.
        /// </summary>
        /// <param name="itemId">The Item's Id</param>
        /// <returns>True/False, if the Item exists in any invoice</returns>
        internal bool ItemIsInInvoice(string itemId)
        {
            var query = ItemsSQL.ItemsInInvoiceCount(itemId);
            var response = ItemsSQL.ExecuteScalarSQL(query);
            var count = Convert.ToInt32(response);
            if (count != 0)
                return true;
            return false;
        }
    }
}
