﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Program2
{
    /// <summary>
    /// Class for Assignment 1(Program 2)
    /// The user inputs 2 integers and the program will perform basic math functions and
    /// then compare the numbers. The output is displayed on the console. No error handling.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            int number1; //Users first number
            int number2; //Users second number
            int sum; //Sum of numbers 1 and 2
            int difference; //Difference of numbers 1 and 2
            int product; //Product of numbers 1 and 2
            int quotient; //Quotient of numbers 1 and 2
            int remainder; //Remainder of numbers 1 and 2

            //Prompt user
            Console.Write("Enter the first integer: ");
            //Collect and store first integer into variable
            number1 = Convert.ToInt32(Console.ReadLine());

            //Prompt user
            Console.Write("Enter the second integer: ");
            //Collect and store second integer into variable
            number2 = Convert.ToInt32(Console.ReadLine());

            //Perform calculations
            sum = number1 + number2; //addition
            difference = number1 - number2; //subtraction
            product = number1 * number2; //multiplication
            quotient = number1 / number2; //division
            remainder = number1 % number2; //modulus

            //Display all calculations
            Console.WriteLine("\nSum: {0} \n" +
                "Difference: {1} \n" +
                "Product: {2} \n" +
                "Quotient: {3} \n" +
                "Remainder: {4}", sum, difference, product, quotient, remainder);
            
            //Display comparison operators
            if(number1 < number2)
            {
                Console.WriteLine("{0} is less than {1}\n" +
                    "{0} is not greater than {1}", number1, number2);
            }
            if (number1 > number2)
            {
                Console.WriteLine("{0} is not less than {1}\n" +
                    "{0} is greater than {1}", number1, number2);
            }
            if (number1 == number2)
            {
                Console.WriteLine("{0} is equal to {1}", number1, number2);
            }
            if (number1 != number2)
            {
                Console.WriteLine("{0} is not equal to {1}", number1, number2);
            }

            Console.Read();//Pause the screen
        }
    }
}
