﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1_Program1
{
    /// <summary>
    /// Class for assignment 1 program 1
    /// The user will enter messages into textboxes and then messageboxes will display
    /// the users messages.
    /// </summary>
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This method handles all events when the top button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            //Result variable for the OK/Cancel selection
            DialogResult result1; 

            //Display the users message on the message box
            result1 = MessageBox.Show("You typed: " + textBox1.Text, "Top textbox", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            //Display the users button selection on the form
            label1.Text = "You clicked the " + result1.ToString() + " button";
        }

        /// <summary>
        /// This method handles all events when the middle button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            //Result variable for the Retry/Cancel selection
            DialogResult result2;

            //Display the users message on the message box
            result2 = MessageBox.Show("You typed: " + textBox2.Text, "Center textbox", MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk);

            //Display the users button selection on the form
            label2.Text = "You clicked the " + result2.ToString() + " button";
        }

        /// <summary>
        /// This method handles all events when the bottom button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            //Result variable for the Abort/Retry/Ignore selection
            DialogResult result3;

            //Display the users message on the message box
            result3 = MessageBox.Show("You typed: " + textBox3.Text, "Bottom textbox", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);

            //Display the users button selection on the form
            label3.Text = "You clicked the " + result3.ToString() + " button";
        }

    }
}
