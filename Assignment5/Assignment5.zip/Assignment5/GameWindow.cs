﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment5
{
    public partial class GameWindow : Form
    {
        /// <summary>
        /// Declaration of the Timer object.
        /// </summary>
        public Timer Timer;

        /// <summary>
        /// Declaration of the Game object.
        /// </summary>
        public Game Game;

        /// <summary>
        /// Counter variable for the number of rounds played.
        /// </summary>
        int rounds = 1;

        /// <summary>
        /// Variable for displaying the number of seconds.
        /// </summary>
        int time = 0;

        /// <summary>
        /// Counter variable for the number of correct answer by the user.
        /// </summary>
        int correctAnswers = 0;

        /// <summary>
        /// Counter variable for the number of wrong answers by the user.
        /// </summary>
        int wrongAnswers = 0;
        
        /// <summary>
        /// Game Window constructor.
        /// </summary>
        /// <param name="game"></param>
        public GameWindow(Game game)
        {
            //Pass the object reference argument from the constructor to this class' game object
            Game = game;
            InitializeComponent();

            //Instantiate and set the timer object
            Timer = new Timer();
            Timer.Interval = 1000;
            Timer.Tick += Timer_Tick;
            Timer.Start();

            //Call the startGame method
            startGame();
        }

        /// <summary>
        /// Method for incrementing and displaying the timer.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = time.ToString();
            time++;
        }

        /// <summary>
        /// Method for closing the window upon clicking the cancel button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Method to handle the users gameType selection and display question to the labels.
        /// </summary>
        private void startGame()
        {
            //Clear the users answer textbox
            txtAnswer.Text = "";

            //Call the appropriate Game object method based on the radio button selected.
            //Addition was selected.
            if(Game.gameType == 1)
            {
                //Call the addition method.
                Game.startAddition();

                //Display the addition question to the window label.
                label1.Text = Game.getFirstOperand().ToString() + " + " +
                          Game.getSecondOperand().ToString() + " = ";
              
            }
            //Subtraction was selected.
            else if(Game.gameType == 2)
            {
                //Call the subtraction method.
                Game.startSubtraction();

                //Display the subtraction question to the window label.
                label1.Text = Game.getFirstOperand().ToString() + " - " +
                          Game.getSecondOperand().ToString() + " = ";
            }
            //Multiplication was selected.
            else if(Game.gameType == 3)
            {
                //Call the multiplication method.
                Game.startMultiplication();

                //Display the multiplication question to the window label.
                label1.Text = Game.getFirstOperand().ToString() + " * " +
                            Game.getSecondOperand().ToString() + " = ";
            }
            //Division was selected.
            else if (Game.gameType == 4)
            {
                //Call the division method.
                Game.startDivision();

                //Display the division question to the window label.
                label1.Text = Game.getFirstOperand().ToString() + " / " +
                            Game.getSecondOperand().ToString() + " = ";
            }
        }

        /// <summary>
        /// Method for handling the user clicking on the submit button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //If the the game hasn't reached the 10th round...
            if(rounds < 10)
            {
                //Check the users answer against the correct answer, if correct increment variable.
                if(txtAnswer.Text == Game.answer.ToString())
                {
                    correctAnswers++;
                }
                //If incorrect, increment the variable.
                else
                {
                    wrongAnswers++;
                }

                //Increment the rounds counter.
                rounds++;

                //Display the round number
                lblRoundNumber.Text = "Round " + rounds.ToString() + "/10";

                //Start a new round.
                startGame();
            }
            //If the game has finished the 10th round...
            else
            {
                //Hide the GameWindow
                this.Hide();

                //Instantiate a FinalScoreWindow object and pass this windows object
                FinalScoreWindow finalScoreWindow = new FinalScoreWindow(this);
                
                //Display the FinalScoreWindow
                finalScoreWindow.ShowDialog();
            }
        }
    }
}
