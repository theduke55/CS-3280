﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class User
    {
        private string sUserName;
        private int iAge;

        public string getUserName()
        {
            return sUserName;
        }

        public int getAge()
        {
            return iAge;
        }

        public User(string sUserName, int iAge)
        {
            this.sUserName = sUserName;
            this.iAge = iAge;
        }
    }
}
