﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment5
{
    public partial class MainWindow : Form
    {
        /// <summary>
        /// Declare the GameWindow object.
        /// </summary>
        GameWindow GameWindow;

        /// <summary>
        /// Declare the User object.
        /// </summary>
        User User;

        /// <summary>
        /// Declare the Game object.
        /// </summary>
        Game Game; //game object used for main menu

        /// <summary>
        /// MainWindow class constructor.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            
            //Instantiate the Game object.
            Game = new Game();
        }

        /// <summary>
        /// Method for handling the Submit button being clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //Ensure text has been entered in the name box
            if(txtName.Text == "")
            {
                //If there isn't any text, display the following error message
                lblError.Visible = true;
                lblError.Text = "ERROR: Please enter your name.";
            }
            else
            {
                //Check if the value entered in the age box is a number
                if (!Int32.TryParse(txtAge.Text, out int age))
                {
                    //If not, display the following error message
                    lblError.Visible = true;
                    lblError.Text = "ERROR: Please enter a valid age (3-10).";
                }
                else if (Int32.TryParse(txtAge.Text, out int validAge))
                {
                    //Check if the age is between 3 and 10
                    if (validAge < 3 || validAge > 10)
                    {
                        //If not, display the following error message
                        lblError.Visible = true;
                        lblError.Text = "ERROR: Please enter a valid age (3-10).";
                    }
                    else
                    {
                        //Check if one of the game types has been selected
                        if(radioButton1.Checked == false && radioButton2.Checked == false && 
                           radioButton3.Checked == false && radioButton4.Checked == false)
                        {
                            //Display the following error message
                            lblError.Visible = true;
                            lblError.Text = "ERROR: Please select a game type.";
                        }
                        else
                        {
                            //Hide the error label
                            lblError.Visible = false;
                            
                            //Assign the game type based on the radio button selected
                            if (radioButton1.Checked)
                            {
                                //Addition
                                Game.gameType = 1;
                            }
                            else if (radioButton2.Checked)
                            {
                                //Subtraction
                                Game.gameType = 2;
                            }
                            else if (radioButton3.Checked)
                            {
                                //Multiplication
                                Game.gameType = 3;
                            }
                            else
                            {
                                //Division
                                Game.gameType = 4;
                            }

                            //Instantiate the GameWindow object
                            GameWindow = new GameWindow(Game);

                            //Pass the age and name to the User object 
                            User = new User(txtName.Text, validAge);

                            //Hide the Main Menu
                            this.Hide();

                            //Display the Game Window
                            GameWindow.ShowDialog();

                            //Display the Main Menu
                            this.Show();
                        }
                    }
                }
            }
        }//Button1_Click
    }//MainWindow class
}//Assignment 5
