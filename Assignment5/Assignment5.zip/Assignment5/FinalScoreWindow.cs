﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment5
{
    public partial class FinalScoreWindow : Form
    {
        /// <summary>
        /// GameWindow object declaration.
        /// </summary>
        public GameWindow gameWindow;

        /// <summary>
        /// FinalScoreWindow constructor.
        /// </summary>
        /// <param name="gameWindow"></param>
        public FinalScoreWindow(GameWindow gameWindow)
        {
            //Instantiate the GameWindow object
            this.gameWindow = gameWindow;
            InitializeComponent();
        }
    }
}
