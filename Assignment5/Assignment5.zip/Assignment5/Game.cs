﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Game
    {
        /// <summary>
        /// Declare the first operand variable.
        /// </summary>
        public int firstOperand;

        /// <summary>
        /// Declare the second operand variable.
        /// </summary>
        public int secondOperand;

        /// <summary>
        /// Declare the user's answer variable.
        /// </summary>
        public int usersAnswer;

        /// <summary>
        /// Declare a variable for the correct answer.
        /// </summary>
        public int answer = 0;

        /// <summary>
        /// Initialize a game type integer 1 = Add, 2 = Subtract, 3 = Multiply, 4 = Divide
        /// </summary>
        public int gameType = 0;

        /// <summary>
        /// Instantiate the random number object.
        /// </summary>
        Random randomNum = new Random();

        /// <summary>
        /// Declare a User object.
        /// </summary>
        public User User;
        
        /// <summary>
        /// Game class constructor.
        /// </summary>
        public Game()
        {
            
        }
        
        /// <summary>
        /// Method for initializing both operands with random numbers between 0-10.
        /// </summary>
        public void getRandomOperands()
        {
            //Get a random number for the first operand
            int f = randomNum.Next(0, 11);
            firstOperand = f;

            //Get a random number for the second operand
            int s = randomNum.Next(0,11);
            secondOperand = s;
        }
        
        /// <summary>
        /// Method to return the first operands value.
        /// </summary>
        /// <returns></returns>
        public int getFirstOperand()
        {
            return firstOperand;
        }
        
        /// <summary>
        /// Method to return the second operands value.
        /// </summary>
        /// <returns></returns>
        public int getSecondOperand()
        {
            return secondOperand;
        }

        /// <summary>
        /// Method for calculating the sum of both operands.
        /// </summary>
        /// <returns></returns>
        public int startAddition()
        {
            getRandomOperands();
            return answer = firstOperand + secondOperand;
        }

        /// <summary>
        /// Method for calculating the difference of both operands 
        /// while ensuring only non-negative integers.
        /// </summary>
        /// <returns></returns>
        public int startSubtraction()
        {
            getRandomOperands();
            //If the first number is larger than the second, return the answer.
            if(firstOperand > secondOperand)
            {
                return answer = firstOperand - secondOperand;
            }
            //Else swap the numbers and then calculate the difference.
            else
            {
                int temp = secondOperand;
                secondOperand = firstOperand;
                firstOperand = temp;
                return answer = firstOperand - secondOperand;
            }
        }

        /// <summary>
        /// Method for calculating the product of both operands.
        /// </summary>
        /// <returns></returns>
        public int startMultiplication()
        {
            getRandomOperands();
            return answer = firstOperand * secondOperand;
        }

        /// <summary>
        /// Method for calculating the quotient of both operands 
        /// while also ensuring whole number answers.
        /// </summary>
        /// <returns></returns>
        public int startDivision()
        {
            getRandomOperands();
            /*If the second number is zero or the quotient of the two operands does not equal 
             * a whole number, generate a new random number for the second operand. */
            while(secondOperand == 0 || firstOperand % secondOperand != 0)
            {
                secondOperand = randomNum.Next(1, 11);
                
            }
            return answer = firstOperand / secondOperand;
        }
    }
}
