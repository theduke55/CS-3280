﻿namespace Assignment2Forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.timesLost = new System.Windows.Forms.Label();
            this.timesWon = new System.Windows.Forms.Label();
            this.timesPlayed = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.userEntry = new System.Windows.Forms.TextBox();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.roll = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.timesLost);
            this.groupBox1.Controls.Add(this.timesWon);
            this.groupBox1.Controls.Add(this.timesPlayed);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(546, 137);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Game Info";
            // 
            // timesLost
            // 
            this.timesLost.AutoSize = true;
            this.timesLost.Location = new System.Drawing.Point(405, 88);
            this.timesLost.Name = "timesLost";
            this.timesLost.Size = new System.Drawing.Size(24, 25);
            this.timesLost.TabIndex = 5;
            this.timesLost.Text = "0";
            // 
            // timesWon
            // 
            this.timesWon.AutoSize = true;
            this.timesWon.Location = new System.Drawing.Point(405, 60);
            this.timesWon.Name = "timesWon";
            this.timesWon.Size = new System.Drawing.Size(24, 25);
            this.timesWon.TabIndex = 4;
            this.timesWon.Text = "0";
            // 
            // timesPlayed
            // 
            this.timesPlayed.AutoSize = true;
            this.timesPlayed.Location = new System.Drawing.Point(405, 31);
            this.timesPlayed.Name = "timesPlayed";
            this.timesPlayed.Size = new System.Drawing.Size(24, 25);
            this.timesPlayed.TabIndex = 3;
            this.timesPlayed.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(234, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of Times Lost: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of Times Won: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Times Played: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(238, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "Enter your guess (1-6): ";
            // 
            // userEntry
            // 
            this.userEntry.Location = new System.Drawing.Point(270, 189);
            this.userEntry.MaxLength = 1;
            this.userEntry.Name = "userEntry";
            this.userEntry.Size = new System.Drawing.Size(100, 31);
            this.userEntry.TabIndex = 1;
            this.userEntry.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pbImage
            // 
            this.pbImage.Location = new System.Drawing.Point(30, 237);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(200, 200);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImage.TabIndex = 3;
            this.pbImage.TabStop = false;
            // 
            // roll
            // 
            this.roll.Location = new System.Drawing.Point(294, 237);
            this.roll.Name = "roll";
            this.roll.Size = new System.Drawing.Size(163, 48);
            this.roll.TabIndex = 0;
            this.roll.Text = "Roll";
            this.roll.UseVisualStyleBackColor = true;
            this.roll.Visible = false;
            this.roll.Click += new System.EventHandler(this.button1_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(294, 315);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(163, 48);
            this.reset.TabIndex = 0;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.button2_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(30, 444);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(913, 196);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 663);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.roll);
            this.Controls.Add(this.pbImage);
            this.Controls.Add(this.userEntry);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Die Guess Game";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label timesLost;
        private System.Windows.Forms.Label timesWon;
        private System.Windows.Forms.Label timesPlayed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox userEntry;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.Button roll;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

