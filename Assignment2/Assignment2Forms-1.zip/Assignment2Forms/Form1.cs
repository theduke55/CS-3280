﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2Forms
{
    public partial class Form1 : Form
    {
        #region Attributes
        /// <summary>
        /// The face of the randomly chosen die
        /// </summary>
        int face;
        /// <summary>
        /// The frequency counter for the number 1 side of the die
        /// </summary>
        double frequency1 = 0;
        /// <summary>
        /// The frequency counter for the number 2 side of the die
        /// </summary>
        double frequency2 = 0;
        /// <summary>
        /// The frequency counter for the number 3 side of the die
        /// </summary>
        double frequency3 = 0;
        /// <summary>
        /// The frequency counter for the number 4 side of the die
        /// </summary>
        double frequency4 = 0;
        /// <summary>
        /// The frequency counter for the number 5 side of the die
        /// </summary>
        double frequency5 = 0;
        /// <summary>
        /// The frequency counter for the number 6 side of the die
        /// </summary>
        double frequency6 = 0;
        /// <summary>
        /// The total number of guesses made by the user
        /// </summary>
        int totalGuesses = 0;
        /// <summary>
        /// The guess made by the user in the textbox
        /// </summary>
        int usersGuess;
        /// <summary>
        /// Counter to be used for user guessing 1
        /// </summary>
        int guessed1 = 0;
        /// <summary>
        /// Counter to be used for user guessing 2
        /// </summary>
        int guessed2 = 0;
        /// <summary>
        /// Counter to be used for user guessing 3
        /// </summary>
        int guessed3 = 0;
        /// <summary>
        /// Counter to be used for user guessing 4
        /// </summary>
        int guessed4 = 0;
        /// <summary>
        /// Counter to be used for user guessing 5
        /// </summary>
        int guessed5 = 0;
        /// <summary>
        /// Counter to be used for user guessing 6
        /// </summary>
        int guessed6 = 0;
        /// <summary>
        /// Counter to be used for user wins
        /// </summary>
        int wins = 0;
        /// <summary>
        /// Counter to be used for user losses
        /// </summary>
        int losses = 0;

        //Create a Random object
        Random randomNumber = new Random();

        #endregion

        #region Methods
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Method that activates when the roll button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //Generate a random number between 1 and 6
            face = randomNumber.Next(1, 7);

            //Update counters based on what random number is generated
            switch (face)
            {
                case 1:
                    ++frequency1;
                    ++totalGuesses;
                    break;
                case 2:
                    ++frequency2;
                    ++totalGuesses;
                    break;
                case 3:
                    ++frequency3;
                    ++totalGuesses;
                    break;
                case 4:
                    ++frequency4;
                    ++totalGuesses;
                    break;
                case 5:
                    ++frequency5;
                    ++totalGuesses;
                    break;
                case 6:
                    ++frequency6;
                    ++totalGuesses;
                    break;
            }

            //Display data of the die face, frequency it occurred, 
            //frequency in percentage, and the number of times the user guessed.
            richTextBox1.Text = "Face\tFrequency\tPercent\t\tNumber of Times Guessed"
                + Environment.NewLine + "1\t" + frequency1 + "\t\t" + calculatePercentage(frequency1) + "%\t\t" + guessed1
                + Environment.NewLine + "2\t" + frequency2 + "\t\t" + calculatePercentage(frequency2) + "%\t\t" + guessed2
                + Environment.NewLine + "3\t" + frequency3 + "\t\t" + calculatePercentage(frequency3) + "%\t\t" + guessed3
                + Environment.NewLine + "4\t" + frequency4 + "\t\t" + calculatePercentage(frequency4) + "%\t\t" + guessed4
                + Environment.NewLine + "5\t" + frequency5 + "\t\t" + calculatePercentage(frequency5) + "%\t\t" + guessed5
                + Environment.NewLine + "6\t" + frequency6 + "\t\t" + calculatePercentage(frequency6) + "%\t\t" + guessed6;

            //Hide the roll button
            roll.Hide();

            //Calculate wins and losses
            if(usersGuess == face)
            {
                ++wins;
            }
            else
            {
                ++losses;
            }

            //Update the number of games played
            timesPlayed.Text = totalGuesses.ToString();
            timesWon.Text = wins.ToString();
            timesLost.Text = losses.ToString();

            //Clear out the users textbox
            userEntry.ResetText();

            pbImage.SizeMode = PictureBoxSizeMode.StretchImage;
            Random rnd = new Random();
            
            for (int i = 1; i < 12; i++)
            {
                int picture = randomNumber.Next(1, 7);
                pbImage.Image = Image.FromFile("die" + picture.ToString() + ".gif");
                pbImage.Refresh();
                Thread.Sleep(100);
            }
        }

        /// <summary>
        /// Calculate the percentage of faces generated.
        /// </summary>
        /// <param name="frequency"></param>
        /// <returns>The frequency to 2 decimal places.</returns>
        private double calculatePercentage(double frequency)
        {
            //Calculate the percentage
            frequency = (frequency / totalGuesses) * 100;

            //Round the percentage to 2 decimals
            frequency = Math.Round(frequency, 2);

            //Return the percentage
            return frequency;
        }

        /// <summary>
        /// Method for events to occur when reset button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            //Reset all of the values back to zero
            frequency1 = 0;
            frequency2 = 0;
            frequency3 = 0;
            frequency4 = 0;
            frequency5 = 0;
            frequency6 = 0;
            totalGuesses = 0;
            guessed1 = 0;
            guessed2 = 0;
            guessed3 = 0;
            guessed4 = 0;
            guessed5 = 0;
            guessed6 = 0;
            wins = 0;
            losses = 0;

            //Clear out the richTextBox
            richTextBox1.Clear();

            //Display the new zero values for each label
            timesPlayed.Text = totalGuesses.ToString();
            timesWon.Text = wins.ToString();
            timesLost.Text = losses.ToString();

            //Hide the roll button
            roll.Hide();

            //Clear out the users textbox
            userEntry.Clear();
        }

        /// <summary>
        /// Method for handling user input into the textbox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //If the user inputs characters not within 1-6, hide the roll button
            while(!Int32.TryParse(userEntry.Text, out usersGuess) || usersGuess < 1 || usersGuess > 6)
            {
                roll.Hide();
                break;
            }

            //If the user enters correct input, increment guesses
            if (Int32.TryParse(userEntry.Text, out usersGuess))
            {
                switch (usersGuess)
                {
                    case 1:
                        guessed1++;
                        break;
                    case 2:
                        guessed2++;
                        break;
                    case 3:
                        guessed3++;
                        break;
                    case 4:
                        guessed4++;
                        break;
                    case 5:
                        guessed5++;
                        break;
                    case 6:
                        guessed6++;
                        break;
                }
                
                //Show the roll button
                roll.Show();
            }
        }//End of textbox1_TextChanged
        #endregion

        
    }//End of Class Form1
}//End of Assignment2_Forms
