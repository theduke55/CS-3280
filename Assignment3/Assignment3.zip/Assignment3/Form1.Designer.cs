﻿namespace Assignment3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.submitCountBtn = new System.Windows.Forms.Button();
            this.numberOfAssignmentsTxt = new System.Windows.Forms.TextBox();
            this.numberOfStudentsTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.resetScoresBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lastStudentBtn = new System.Windows.Forms.Button();
            this.nextStudentBtn = new System.Windows.Forms.Button();
            this.previousStudentBtn = new System.Windows.Forms.Button();
            this.firstStudentBtn = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.studentNumberLbl = new System.Windows.Forms.Label();
            this.saveNameBtn = new System.Windows.Forms.Button();
            this.studentNameTxt = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.saveScoreBtn = new System.Windows.Forms.Button();
            this.assignmentScoreTxt = new System.Windows.Forms.TextBox();
            this.assignmentNumberTxt = new System.Windows.Forms.TextBox();
            this.assignmentScoreLbl = new System.Windows.Forms.Label();
            this.assignmentNumberLbl = new System.Windows.Forms.Label();
            this.displayScoresBtn = new System.Windows.Forms.Button();
            this.displayRtb = new System.Windows.Forms.RichTextBox();
            this.errorLbl = new System.Windows.Forms.Label();
            this.errorLbl2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.submitCountBtn);
            this.groupBox1.Controls.Add(this.numberOfAssignmentsTxt);
            this.groupBox1.Controls.Add(this.numberOfStudentsTxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(50, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(699, 164);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Counts";
            // 
            // submitCountBtn
            // 
            this.submitCountBtn.Location = new System.Drawing.Point(493, 43);
            this.submitCountBtn.Name = "submitCountBtn";
            this.submitCountBtn.Size = new System.Drawing.Size(189, 73);
            this.submitCountBtn.TabIndex = 4;
            this.submitCountBtn.Text = "Submit Counts";
            this.submitCountBtn.UseVisualStyleBackColor = true;
            this.submitCountBtn.Click += new System.EventHandler(this.button9_Click);
            // 
            // numberOfAssignmentsTxt
            // 
            this.numberOfAssignmentsTxt.Location = new System.Drawing.Point(349, 93);
            this.numberOfAssignmentsTxt.Name = "numberOfAssignmentsTxt";
            this.numberOfAssignmentsTxt.Size = new System.Drawing.Size(100, 31);
            this.numberOfAssignmentsTxt.TabIndex = 3;
            // 
            // numberOfStudentsTxt
            // 
            this.numberOfStudentsTxt.Location = new System.Drawing.Point(349, 43);
            this.numberOfStudentsTxt.Name = "numberOfStudentsTxt";
            this.numberOfStudentsTxt.Size = new System.Drawing.Size(100, 31);
            this.numberOfStudentsTxt.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(252, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of Assignments: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Students: ";
            // 
            // resetScoresBtn
            // 
            this.resetScoresBtn.Location = new System.Drawing.Point(805, 82);
            this.resetScoresBtn.Name = "resetScoresBtn";
            this.resetScoresBtn.Size = new System.Drawing.Size(189, 73);
            this.resetScoresBtn.TabIndex = 1;
            this.resetScoresBtn.Text = "Reset Scores";
            this.resetScoresBtn.UseVisualStyleBackColor = true;
            this.resetScoresBtn.Click += new System.EventHandler(this.resetScoresBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lastStudentBtn);
            this.groupBox2.Controls.Add(this.nextStudentBtn);
            this.groupBox2.Controls.Add(this.previousStudentBtn);
            this.groupBox2.Controls.Add(this.firstStudentBtn);
            this.groupBox2.Location = new System.Drawing.Point(50, 235);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(944, 106);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigate";
            // 
            // lastStudentBtn
            // 
            this.lastStudentBtn.Location = new System.Drawing.Point(743, 46);
            this.lastStudentBtn.Name = "lastStudentBtn";
            this.lastStudentBtn.Size = new System.Drawing.Size(185, 43);
            this.lastStudentBtn.TabIndex = 3;
            this.lastStudentBtn.Text = "Last Student>>";
            this.lastStudentBtn.UseVisualStyleBackColor = true;
            this.lastStudentBtn.Click += new System.EventHandler(this.lastStudentBtn_Click);
            // 
            // nextStudentBtn
            // 
            this.nextStudentBtn.Location = new System.Drawing.Point(506, 46);
            this.nextStudentBtn.Name = "nextStudentBtn";
            this.nextStudentBtn.Size = new System.Drawing.Size(185, 43);
            this.nextStudentBtn.TabIndex = 2;
            this.nextStudentBtn.Text = "Next Student >";
            this.nextStudentBtn.UseVisualStyleBackColor = true;
            this.nextStudentBtn.Click += new System.EventHandler(this.nextStudentBtn_Click);
            // 
            // previousStudentBtn
            // 
            this.previousStudentBtn.Location = new System.Drawing.Point(269, 46);
            this.previousStudentBtn.Name = "previousStudentBtn";
            this.previousStudentBtn.Size = new System.Drawing.Size(185, 43);
            this.previousStudentBtn.TabIndex = 1;
            this.previousStudentBtn.Text = "<Prev Student";
            this.previousStudentBtn.UseVisualStyleBackColor = true;
            this.previousStudentBtn.Click += new System.EventHandler(this.previousStudentBtn_Click);
            // 
            // firstStudentBtn
            // 
            this.firstStudentBtn.Location = new System.Drawing.Point(32, 46);
            this.firstStudentBtn.Name = "firstStudentBtn";
            this.firstStudentBtn.Size = new System.Drawing.Size(185, 43);
            this.firstStudentBtn.TabIndex = 0;
            this.firstStudentBtn.Text = "<<First Student";
            this.firstStudentBtn.UseVisualStyleBackColor = true;
            this.firstStudentBtn.Click += new System.EventHandler(this.firstStudentBtn_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.studentNumberLbl);
            this.groupBox3.Controls.Add(this.saveNameBtn);
            this.groupBox3.Controls.Add(this.studentNameTxt);
            this.groupBox3.Location = new System.Drawing.Point(50, 373);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(944, 127);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Student Info";
            // 
            // studentNumberLbl
            // 
            this.studentNumberLbl.AutoSize = true;
            this.studentNumberLbl.Location = new System.Drawing.Point(26, 50);
            this.studentNumberLbl.Name = "studentNumberLbl";
            this.studentNumberLbl.Size = new System.Drawing.Size(118, 25);
            this.studentNumberLbl.TabIndex = 3;
            this.studentNumberLbl.Text = "Student #X";
            // 
            // saveNameBtn
            // 
            this.saveNameBtn.Location = new System.Drawing.Point(734, 47);
            this.saveNameBtn.Name = "saveNameBtn";
            this.saveNameBtn.Size = new System.Drawing.Size(151, 37);
            this.saveNameBtn.TabIndex = 2;
            this.saveNameBtn.Text = "Save Name";
            this.saveNameBtn.UseVisualStyleBackColor = true;
            this.saveNameBtn.Click += new System.EventHandler(this.saveNameBtn_Click);
            // 
            // studentNameTxt
            // 
            this.studentNameTxt.Location = new System.Drawing.Point(214, 50);
            this.studentNameTxt.Name = "studentNameTxt";
            this.studentNameTxt.Size = new System.Drawing.Size(470, 31);
            this.studentNameTxt.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.saveScoreBtn);
            this.groupBox4.Controls.Add(this.assignmentScoreTxt);
            this.groupBox4.Controls.Add(this.assignmentNumberTxt);
            this.groupBox4.Controls.Add(this.assignmentScoreLbl);
            this.groupBox4.Controls.Add(this.assignmentNumberLbl);
            this.groupBox4.Location = new System.Drawing.Point(50, 522);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(944, 151);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Student Info";
            // 
            // saveScoreBtn
            // 
            this.saveScoreBtn.Location = new System.Drawing.Point(534, 49);
            this.saveScoreBtn.Name = "saveScoreBtn";
            this.saveScoreBtn.Size = new System.Drawing.Size(165, 49);
            this.saveScoreBtn.TabIndex = 4;
            this.saveScoreBtn.Text = "Save Score";
            this.saveScoreBtn.UseVisualStyleBackColor = true;
            this.saveScoreBtn.Click += new System.EventHandler(this.saveScoreBtn_Click);
            // 
            // assignmentScoreTxt
            // 
            this.assignmentScoreTxt.Location = new System.Drawing.Point(364, 95);
            this.assignmentScoreTxt.Name = "assignmentScoreTxt";
            this.assignmentScoreTxt.Size = new System.Drawing.Size(107, 31);
            this.assignmentScoreTxt.TabIndex = 3;
            // 
            // assignmentNumberTxt
            // 
            this.assignmentNumberTxt.Location = new System.Drawing.Point(364, 39);
            this.assignmentNumberTxt.Name = "assignmentNumberTxt";
            this.assignmentNumberTxt.Size = new System.Drawing.Size(107, 31);
            this.assignmentNumberTxt.TabIndex = 2;
            // 
            // assignmentScoreLbl
            // 
            this.assignmentScoreLbl.AutoSize = true;
            this.assignmentScoreLbl.Location = new System.Drawing.Point(26, 98);
            this.assignmentScoreLbl.Name = "assignmentScoreLbl";
            this.assignmentScoreLbl.Size = new System.Drawing.Size(198, 25);
            this.assignmentScoreLbl.TabIndex = 1;
            this.assignmentScoreLbl.Text = "Assignment Score: ";
            // 
            // assignmentNumberLbl
            // 
            this.assignmentNumberLbl.AutoSize = true;
            this.assignmentNumberLbl.Location = new System.Drawing.Point(26, 42);
            this.assignmentNumberLbl.Name = "assignmentNumberLbl";
            this.assignmentNumberLbl.Size = new System.Drawing.Size(322, 25);
            this.assignmentNumberLbl.TabIndex = 0;
            this.assignmentNumberLbl.Text = "Enter assignment number (1-X): ";
            // 
            // displayScoresBtn
            // 
            this.displayScoresBtn.Location = new System.Drawing.Point(380, 682);
            this.displayScoresBtn.Name = "displayScoresBtn";
            this.displayScoresBtn.Size = new System.Drawing.Size(330, 71);
            this.displayScoresBtn.TabIndex = 5;
            this.displayScoresBtn.Text = "Display Scores";
            this.displayScoresBtn.UseVisualStyleBackColor = true;
            this.displayScoresBtn.Click += new System.EventHandler(this.displayScoresBtn_Click);
            // 
            // displayRtb
            // 
            this.displayRtb.Location = new System.Drawing.Point(50, 765);
            this.displayRtb.Name = "displayRtb";
            this.displayRtb.Size = new System.Drawing.Size(1208, 376);
            this.displayRtb.TabIndex = 6;
            this.displayRtb.Text = "";
            this.displayRtb.WordWrap = false;
            // 
            // errorLbl
            // 
            this.errorLbl.AutoSize = true;
            this.errorLbl.Location = new System.Drawing.Point(399, 8);
            this.errorLbl.Name = "errorLbl";
            this.errorLbl.Size = new System.Drawing.Size(0, 25);
            this.errorLbl.TabIndex = 7;
            // 
            // errorLbl2
            // 
            this.errorLbl2.AutoSize = true;
            this.errorLbl2.Location = new System.Drawing.Point(414, 498);
            this.errorLbl2.Name = "errorLbl2";
            this.errorLbl2.Size = new System.Drawing.Size(0, 25);
            this.errorLbl2.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1300, 1179);
            this.Controls.Add(this.errorLbl2);
            this.Controls.Add(this.errorLbl);
            this.Controls.Add(this.displayRtb);
            this.Controls.Add(this.displayScoresBtn);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.resetScoresBtn);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Scores";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox numberOfAssignmentsTxt;
        private System.Windows.Forms.TextBox numberOfStudentsTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button resetScoresBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button lastStudentBtn;
        private System.Windows.Forms.Button nextStudentBtn;
        private System.Windows.Forms.Button previousStudentBtn;
        private System.Windows.Forms.Button firstStudentBtn;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button saveNameBtn;
        private System.Windows.Forms.TextBox studentNameTxt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button saveScoreBtn;
        private System.Windows.Forms.TextBox assignmentScoreTxt;
        private System.Windows.Forms.TextBox assignmentNumberTxt;
        private System.Windows.Forms.Label assignmentScoreLbl;
        private System.Windows.Forms.Label assignmentNumberLbl;
        private System.Windows.Forms.Button displayScoresBtn;
        private System.Windows.Forms.RichTextBox displayRtb;
        private System.Windows.Forms.Button submitCountBtn;
        private System.Windows.Forms.Label errorLbl;
        private System.Windows.Forms.Label studentNumberLbl;
        private System.Windows.Forms.Label errorLbl2;
    }
}

