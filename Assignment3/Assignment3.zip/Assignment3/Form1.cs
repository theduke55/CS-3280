﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment3
{
    public partial class Form1 : Form
    {
        #region Attributes
        /// <summary>
        /// Single dimension array for student names.
        /// </summary>
        private string[] sStudentArray;
        /// <summary>
        /// Multi-dimensional array for student scores.
        /// </summary>
        private int[,] iAssignmentArray;
        /// <summary>
        /// Array position counter for student array.
        /// </summary>
        private static int studentArrayCounter = 1;
        /// <summary>
        /// Array position counter for assignment array
        /// </summary>
        private static int assignmentArrayCounter = 1;
        #endregion

        #region Methods
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Method for dealing with error handling for the number of students and assignments.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            //Check if the user entered a valid number 1-10
            //If not, print an error message to the label
            if(!Int32.TryParse(numberOfStudentsTxt.Text, out int temp1) || temp1 < 1 || temp1 > 10)
            {
                errorLbl.Text = "Please enter a valid number of students (1-10)";
            }
            //If the number is valid for students then continue
            else if(Int32.TryParse(numberOfStudentsTxt.Text, out int temp2) && temp2 > 0 && temp2 < 11)
            {
                //Create the single dimension student array
                sStudentArray = new string[temp2];

                //Populate the array with default names
                defaultNames(sStudentArray);

                //Change the label for student numbers
                studentNumberLbl.Text = "Student #" + studentArrayCounter;

                //Reset the label text
                errorLbl.ResetText();

                //Check if the user entered a number 1-99 for the number of assignments
                //If the user entered bad input, print error message to the label
                if (!Int32.TryParse(numberOfAssignmentsTxt.Text, out int temp3) || temp3 < 1 || temp3 > 99)
                {
                    errorLbl.Text = "Please enter a valid number of assignments (1-99)";
                }
                //If the user entered valid input, continue
                else if (Int32.TryParse(numberOfAssignmentsTxt.Text, out int temp4) && temp4 > 0 && temp4 < 100)
                {
                    //Create the multi-dimensional assignment array using the number of students
                    iAssignmentArray = new int[temp2, temp4];

                    //Populate the array with default scores
                    defaultScores(iAssignmentArray);

                    //Change the label for assignments
                    studentNumberLbl.Text = "Student #" + studentArrayCounter;
                    assignmentNumberLbl.Text = "Enter Assignment Number (1-" + temp4 + ")";

                    //Reset the label text
                    errorLbl.ResetText();
                }
            }
            
        }

        /// <summary>
        /// Method for assigning each student a default name.
        /// </summary>
        /// <param name="arr"></param>
        public void defaultNames(string[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = "Student #" + (i + 1);
            }
        }

        /// <summary>
        /// Method for populating the array with a zero default score.
        /// </summary>
        /// <param name="arr"></param>
        public void defaultScores(int[,] arr)
        {
            for (int rows = 0; rows < arr.GetLength(0); rows++)
            {
                for (int cols = 0; cols < arr.GetLength(1); cols++)
                {
                    arr[rows, cols] = 0;
                }
            }
        }

        /// <summary>
        /// Method to locate the first students information in the array.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void firstStudentBtn_Click(object sender, EventArgs e)
        {
            studentArrayCounter = 1;
            studentNumberLbl.Text = "Student #" + studentArrayCounter;
            studentNameTxt.Text = sStudentArray[studentArrayCounter - 1];
        }

        /// <summary>
        /// Method to jump to the end of the array for the students information.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lastStudentBtn_Click(object sender, EventArgs e)
        {
            studentArrayCounter = sStudentArray.Length;
            studentNumberLbl.Text = "Student #" + studentArrayCounter;
            studentNameTxt.Text = sStudentArray[studentArrayCounter - 1];
        }

        /// <summary>
        /// Method for cycling left/toward the start of the array.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void previousStudentBtn_Click(object sender, EventArgs e)
        {
            //If the current student isn't at the start allow for movement
            if(studentArrayCounter > 1)
            {
                --studentArrayCounter;
                studentNumberLbl.Text = "Student #" + studentArrayCounter;
                studentNameTxt.Text = sStudentArray[studentArrayCounter - 1];
            }
        }

        /// <summary>
        /// Method for cycling forward through the array of students.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nextStudentBtn_Click(object sender, EventArgs e)
        {
            //If the array location isn't greater than the array length shift to the next spot
            if (studentArrayCounter < sStudentArray.Length)
            {
                ++studentArrayCounter;
                studentNumberLbl.Text = "Student #" + studentArrayCounter;
                studentNameTxt.Text = sStudentArray[studentArrayCounter - 1];
            }
        }

        /// <summary>
        /// Stores the updated student name into the array.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveNameBtn_Click(object sender, EventArgs e)
        {
            sStudentArray[studentArrayCounter - 1] = studentNameTxt.Text;
        }

        /// <summary>
        /// This method handles the math computations, error handling for assignments and scores, and prints the results.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void displayScoresBtn_Click(object sender, EventArgs e)
        {
            //Create a StringBuilder object
            StringBuilder results = new StringBuilder();

            //Reset the counters
            studentArrayCounter = 1;
            assignmentArrayCounter = 1;

            //Format the Student title
            results.Append("Student Name\t\t");

            //Format the assignment number titles by looping through the assignment array
            for (int i = 0; i < iAssignmentArray.GetLength(1); i++)
            {
                results.Append("#" + assignmentArrayCounter + "\t");
                assignmentArrayCounter++;
            }

            //Add the Average and Grade titles
            results.Append("Average\tGrade");

            //Go to the next line after the titles are written
            results.Append(Environment.NewLine);
            
            //Format the student name and scores for each assignment
            for(int i = 0; i < iAssignmentArray.GetLength(0); i++)
            {
                results.Append(sStudentArray[studentArrayCounter- 1] + "\t\t");
                studentArrayCounter++;

                //Set average
                int average = 0;

                for(int j = 0; j < iAssignmentArray.GetLength(1); j++)
                {
                    results.Append(iAssignmentArray[i, j] + "\t");
                    average += iAssignmentArray[i, j];
                }

                //Compute the average
                average = average / iAssignmentArray.GetLength(1);

                //Compute the letter grade
                string grade;
                if (average >= 93)
                    grade = "A";
                else if (average >= 90 && average < 93)
                    grade = "A-";
                else if (average >= 87 && average < 90)
                    grade = "B+";
                else if (average >= 83 && average < 87)
                    grade = "B";
                else if (average >= 80 && average < 83)
                    grade = "B-";
                else if (average >= 77 && average < 80)
                    grade = "C+";
                else if (average >= 73 && average < 77)
                    grade = "C";
                else if (average >= 70 && average < 73)
                    grade = "C-";
                else if (average >= 67 && average < 70)
                    grade = "D+";
                else if (average >= 63 && average < 67)
                    grade = "D";
                else if (average >= 60 && average < 63)
                    grade = "D-";
                else
                    grade = "E";

                //Append the average and the letter grade
                results.Append(average + "\t" + grade + "\t" + Environment.NewLine);
            }

            //Print everything to the display rich text box
            displayRtb.Text = results.ToString();

            //Reset the values to student 1 after clicking the display button
            studentArrayCounter = 1;
            studentNumberLbl.Text = "Student #" + studentArrayCounter;
            studentNameTxt.Text = sStudentArray[studentArrayCounter - 1];
        }

        /// <summary>
        /// Method that ensures valid assignment data and stores students scores into the array
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveScoreBtn_Click(object sender, EventArgs e)
        {
            //Check if the user entered a number 1-X for the number of assignments
            //If the user entered bad input, print error message to the label
            if (!Int32.TryParse(assignmentNumberTxt.Text, out int temp1) || temp1 < 1 || temp1 > iAssignmentArray.GetLength(1))
            {
                errorLbl2.Text = "Please enter a valid assignment number(1-" + iAssignmentArray.GetLength(1) + ")";
            }

            //If there is a valid assignment number, continue
            else if (Int32.TryParse(assignmentNumberTxt.Text, out int temp2) && temp2 >= 1 && temp2 <= iAssignmentArray.GetLength(1))
            {
                //Check if the user entered a number 0-100 for the score
                //If the user entered bad input, print error message to the label
                if (!Int32.TryParse(assignmentScoreTxt.Text, out int temp3) || temp3 < 0 || temp3 > 100)
                {
                    errorLbl2.Text = "Please enter a valid score(1-100)";
                }

                //If there is a valid score, continue
                else if(Int32.TryParse(assignmentScoreTxt.Text, out int temp4) && temp4 >= 0 && temp3 <= 100)
                {
                    //Convert the entered score from a string to an integer
                    Int32.TryParse(assignmentScoreTxt.Text, out int score);

                    //Save the score to the appropriate location in the assignment array
                    iAssignmentArray[studentArrayCounter - 1, temp2 - 1] = score;

                    //Clear the error message if any
                    errorLbl2.ResetText();
                }
            }
        }

        /// <summary>
        /// Method for deleting the current form and creating a new one.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetScoresBtn_Click(object sender, EventArgs e)
        {
            //Create a new form and dispose of the current one
            Form1 NewForm = new Form1();
            NewForm.Show();
            this.Dispose(false);
        }
        #endregion
    }//End of Form1
}//End of Assignment3
